"""
extension:    HelloWorldExtension
handle:       hello_world_extension
version:      0.1
author:       Samuel Abels
author-email: spam2@debain.org
description:  A simple extension for the tests.
              It is also intended that the description
              is a multi line string to have that tested.
runtime_dependency: spiff>=0.5 spoff=2.5
install_time_dependency: spiff>=0.1
"""

class HelloWorldExtension:
   def __init__(self):
      pass
